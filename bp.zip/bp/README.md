# orm-hibernate

###### Een simpel gebruikers applicatie met maven als build tool en hibernate als implementatie van de Java Persistence Api.

De applicatie kan makkelijk als basis gebruikt worden op basis van de configuratie en de architectuurd die het al heeft.
